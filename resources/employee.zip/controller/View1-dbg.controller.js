sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/Fragment",
    "sap/ui/model/json/JSONModel"
],
    function (Controller, Fragment, JSONModel) {
        "use strict";

        return Controller.extend("employee.controller.View1", {
            onInit: function () {
                var Model = this.getOwnerComponent().getModel("global");
                var url = this.getOwnerComponent().getModel().sServiceUrl;
                $.ajax({
                    type: "GET",
                    contentType: "application/json",
                    url: url + "EmpInfo",
                    success: function (response) {
                        Model.setProperty("/aEmpInfo", response.value[0]);
                        var sEmp = Model.getProperty("/aEmpInfo/empid");
                        $.ajax({
                            type: "GET",
                            contentType: "application/json",
                            url: url + "TravelRequest?$filter=reqstatus%20ne%20%27Completed%27&$orderby=REQID%20desc",
                            // url: url + "TravelRequest?$filter=reqstatus%20eq%20%27PendingM%27%20and%20empid%20eq%20%27" + sEmp + "'",
                            success: function (response) {
                                for (let i = 0; i < response.value.length; i++) {
                                    if (response.value[i].triptype == 1) {
                                        response.value[i].triptype = "One way";
                                    }
                                    else {
                                        response.value[i].triptype = "Round way";
                                    }
                                    if (response.value[i].reqstatus == "PendingM") {
                                        response.value[i].reqstatus = "Pending with Manager";
                                    }
                                    else if (response.value[i].reqstatus == "ApprovedM") {
                                        response.value[i].reqstatus = "Approved by Manager";
                                    }
                                    else if (response.value[i].reqstatus == "ApprovedF") {
                                        response.value[i].reqstatus = "Approved by Finance";
                                    }
                                    else if (response.value[i].reqstatus == "RejectedM") {
                                        response.value[i].reqstatus = "Rejected by Manager";
                                    }
                                    else if (response.value[i].reqstatus == "RejectedF") {
                                        response.value[i].reqstatus = "Rejected by Finance";
                                    }
                                }
                                Model.setProperty("/aUpComingtrip", response.value);
                            }
                        })

                    }
                });
                $.ajax({
                    type: "GET",
                    contentType: "application/json",
                    url: url + "DepartureCity",
                    success: function (response) {
                        Model.setProperty("/aDeparture", response.value);
                    }
                });

            },

            onPressUpload: async function () {
                var aDataExtract = [];
                const idUploadSet = this.getView().byId("idUploadSet"),
                    aItems = idUploadSet.getItems(),
                    serviceUrl = this.getOwnerComponent().getModel().getServiceUrl(),
                    globalModel = this.getOwnerComponent().getModel("global")
                this.getView().setBusy(true);
                try {
                    for (let i = 0; i < aItems.length; i++) {
                        const file = aItems[i],
                            object = file.getFileObject(),
                            content = await this._FileToArrayBuffer(object),
                            filename = file.getFileName();

                        await $.ajax({
                            type: "POST",
                            contentType: "application/json; charset=utf-8",
                            url: `${serviceUrl}DocExtract`,
                            data: JSON.stringify({
                                filename, content
                            }),
                            success: function (response) {
                                globalModel.setProperty("/aDocExtractID", response.value.id);
                            },
                        })
                        this.getView().setBusy(false);
                        sap.m.MessageBox.success("File uploaded successfully");
                        idUploadSet.removeAllItems();
                        var sID = globalModel.getProperty("/aDocExtractID");
                        sID = sID.replace(/"/g, "'");
                        $.ajax({
                            type: "GET",
                            contentType: "application/json",
                            // url: `${serviceUrl}GetExtract(id='${sID}')`,
                            url:serviceUrl + "GetExtract(id='" + sID + "')",
                            success: function (response) {
                                for (var i in response.value.extraction.headerFields) {
                                    var obj = {
                                        "exname": response.value.extraction.headerFields[i].name,
                                        "category": response.value.extraction.headerFields[i].category,
                                        "value": response.value.extraction.headerFields[i].value.toString(),
                                        "type": response.value.extraction.headerFields[i].type,
                                        "label": response.value.extraction.headerFields[i].label,
                                        "description": response.value.extraction.headerFields[i].description
                                    }
                                    aDataExtract.push(obj);
                                }
                                globalModel.setProperty("/aDataExtract", aDataExtract);

                            }
                        })


                    }
                } catch (error) {
                    this.getView().setBusy(false);
                    console.error(error)
                }
            },

            _FileToArrayBuffer: function (file) {
                return new Promise((resolve, reject) => {
                    // eslint-disable-next-line no-undef
                    const reader = new FileReader();
                    reader.readAsArrayBuffer(file);
                    reader.onload = () => resolve(Array.from(new Uint8Array(reader.result)));
                    reader.onerror = error => reject(error);
                });
            },





            onCreateNew: function (oEvent) {
                var oButton = oEvent.getSource(),
                    oView = this.getView();

                if (!this._pDialog) {
                    this._pDialog = Fragment.load({
                        id: oView.getId(),
                        name: "employee.fragments.Createnew",
                        controller: this
                    }).then(function (oDialog) {
                        oDialog.setModel(oView.getModel());
                        return oDialog;
                    });
                }

                this._pDialog.then(function (oDialog) {
                    oDialog.open();
                });
                oView.byId("rbg1").setSelectedIndex(0);
                oView.byId("airid").setVisible(true);
                oView.byId("airlines").setSelectedIndex(0);
                oView.byId("purposetravel").setValue("");
                oView.byId("departure").setValue("");
                oView.byId("destination").setValue("");
                oView.byId("triptype").setSelectedIndex(0);
                oView.byId("DP1").setValue("");
                oView.byId("DP2").setValue("");
                oView.byId("accom").setSelectedIndex(0);
                oView.byId("anyprefrence").setVisible(true);
                oView.byId("anyprefrence").setValue("");
                oView.byId("additional").setValue("");
                oView.byId("purposetravel").setValueState("None");
                oView.byId("departure").setValueState("None");
                oView.byId("destination").setValueState("None");
                oView.byId("DP1").setValueState("None");
                oView.byId("DP2").setValueState("None");

            },

            onPressReq: function (oEvent) {

                var Model = this.getOwnerComponent().getModel("global");
                var url = this.getOwnerComponent().getModel().sServiceUrl;
                var ReqID = oEvent.getSource().getBindingContext("global").getObject().REQID;
                var oButton = oEvent.getSource(),
                    oView = this.getView();
                if (!this._pDialogTrReq) {
                    this._pDialogTrReq = Fragment.load({
                        id: oView.getId(),
                        name: "employee.fragments.CreatedReq",
                        controller: this
                    }).then(function (oDialog) {
                        oDialog.setModel(oView.getModel());
                        return oDialog;
                    });
                }
                this._pDialogTrReq.then(function (oDialog) {
                    oDialog.open();

                });
                $.ajax({
                    type: "GET",
                    contentType: "application/json",
                    url: url + "TravelRequest?$filter=REQID%20eq%20" + ReqID,
                    success: function (response) {
                        Model.setProperty("/aCreatedRequest", response.value);
                        oView.byId("radioGroup").setSelectedIndex(response.value[0].travelpreference);
                        if (response.value[0].traveltype == null) {
                            oView.byId("vboxairlines").setVisible(false);
                        }
                        else {
                            oView.byId("vboxairlines").setVisible(true);
                            oView.byId("airlinesradio").setSelectedIndex(response.value[0].traveltype);
                        }
                        oView.byId("purposetravel1").setValue(response.value[0].purposeoftravel);
                        oView.byId("triptype1").setSelectedIndex(response.value[0].triptype);
                        oView.byId("departure1").setValue(response.value[0].departcity);
                        oView.byId("destination1").setValue(response.value[0].destcity);
                        oView.byId("accomoda1").setSelectedIndex(response.value[0].accomodation);
                        if (response.value[0].accomodation == 1) {
                            oView.byId("prefernceid").setVisible(false);
                            oView.byId("anyprefrence1").setVisible(false);
                        }
                        else {
                            oView.byId("prefernceid").setVisible(true);
                            oView.byId("anyprefrence1").setVisible(true);
                            oView.byId("anyprefrence1").setValue(response.value[0].accpreference);
                        }
                        oView.byId("additional1").setValue(response.value[0].empnotes);
                        oView.byId("DP4").setValue(response.value[0].departdate);
                        oView.byId("DP3").setValue(response.value[0].returndate);
                        if(response.value[0].reqstatus == "RejectedM" || response.value[0].reqstatus == "RejectedF"){
                            oView.byId("createdupdate").setEnabled(true);
                            oView.byId("radioGroup").setEditable(true);
                            oView.byId("airlinesradio").setEditable(true);
                            oView.byId("purposetravel1").setEditable(true);
                            oView.byId("departure1").setEditable(true);
                            oView.byId("destination1").setEditable(true);
                            oView.byId("triptype1").setEditable(true);
                            oView.byId("DP4").setEditable(true);
                            oView.byId("DP3").setEditable(true);
                            oView.byId("accomoda1").setEditable(true);
                            oView.byId("anyprefrence1").setEditable(true);
                            oView.byId("additional1").setEditable(true);
                        }
                        else{
                            oView.byId("createdupdate").setEnabled(false);
                            oView.byId("radioGroup").setEditable(false);
                            oView.byId("airlinesradio").setEditable(false);
                            oView.byId("purposetravel1").setEditable(false);
                            oView.byId("departure1").setEditable(false);
                            oView.byId("destination1").setEditable(false);
                            oView.byId("triptype1").setEditable(false);
                            oView.byId("DP4").setEditable(false);
                            oView.byId("DP3").setEditable(false);
                            oView.byId("anyprefrence1").setEditable(false);
                            oView.byId("additional1").setEditable(false);
                           
                        }
                    }
                })

            },

            onSubmit1:function(){
                var bFlag = true;
                var traveltype;
                var accpreference;
                var Model = this.getOwnerComponent().getModel("global");
                var url = this.getOwnerComponent().getModel().sServiceUrl;
                var empid = Model.getProperty("/aEmpInfo/empid");
                var fistname = Model.getProperty("/aEmpInfo/firstname");
                var lastname = Model.getProperty("/aEmpInfo/lastname");
                var dob = Model.getProperty("/aEmpInfo/dob");
                var dept = Model.getProperty("/aEmpInfo/dept");
                var emailid = Model.getProperty("/aEmpInfo/empemail");
                var mgrname = Model.getProperty("/aEmpInfo/mgrname");
                var mgremail = Model.getProperty("/aEmpInfo/mgremail");
                var mgrid = Model.getProperty("/aEmpInfo/mgrid");
                if(Model.getProperty("/aDataExtract") == undefined){
                    Model.setProperty("/aDataExtract", []);
                }
                else{
                    Model.setProperty("/aDataExtract", Model.getProperty("/aDataExtract"));
                }
                var dDepartdate = new Date(this.getView().byId("DP1").mProperties.dateValue).getFullYear() + '-' + (new Date(this.getView().byId("DP1").mProperties.dateValue).getMonth() + 1) + '-' + this.onlPad(new Date(this.getView().byId("DP1").mProperties.dateValue).getDate(), 2);

                var Travel = this.getView().byId("rbg1").getSelectedButton().mProperties.text;
                if (Travel == "Car" || Travel == "Train") {
                    traveltype = null;
                }
                else {
                    traveltype = this.getView().byId("airlines").getSelectedIndex();
                }
                if (this.getView().byId("accom").getSelectedButton().mProperties.text != "Yes") {
                    accpreference = "";
                }
                else {
                    accpreference = this.getView().byId("anyprefrence").getValue();
                }
                if (this.getView().byId("triptype").getSelectedIndex() == 0) {
                    var dReturn = null;
                }
                else {
                    var dReturn = new Date(this.getView().byId("DP2").mProperties.dateValue).getFullYear() + '-' + (new Date(this.getView().byId("DP2").mProperties.dateValue).getMonth() + 1) + '-' + this.onlPad(new Date(this.getView().byId("DP2").mProperties.dateValue).getDate(), 2);
                }
                if (this.getView().byId("purposetravel").getValue() == "") {
                    bFlag = false;
                    this.getView().byId("purposetravel").setValueState("Error");
                }
                if (this.getView().byId("departure").getValue() == "") {
                    bFlag = false;
                    this.getView().byId("departure").setValueState("Error");
                }
                if (this.getView().byId("destination").getValue() == "") {
                    bFlag = false;
                    this.getView().byId("destination").setValueState("Error");
                }
                if (this.getView().byId("DP1").getValue() == "") {
                    bFlag = false;
                    this.getView().byId("DP1").setValueState("Error");
                }
                if (this.getView().byId("triptype").getSelectedIndex == 1 && this.getView().byId("DP2").getValue == "") {
                    bFlag = false;
                    this.getView().byId("DP2").setValueState("Error");
                }
                // if (this.getView().byId("departure").getValue() === this.getView().byId("destination").getValue()) {
                //     sap.m.MessageBox.warning("Departure and destination cannot be same");
                // }
                if (bFlag == true) {
                    var payload = {
                        "empid": empid,
                        "firstname": fistname,
                        "lastname": lastname,
                        "dob": dob,
                        "dept": dept,
                        "emergencycontactno": "",
                        "mobno": "",
                        "emailid": emailid,
                        "address": "Pune",
                        "mgrid": mgrid,
                        "mgrname": mgrname,
                        "mgremail": mgremail,
                        "mgrcontact": "7876354625",
                        // "reqstatus": "",
                        "travelpreference": this.getView().byId("rbg1").getSelectedIndex(),
                        "traveltype": traveltype,
                        "purposeoftravel": this.getView().byId("purposetravel").getValue(),
                        "departcity": this.getView().byId("departure").getValue(),
                        "destcity": this.getView().byId("destination").getValue(),
                        "triptype": this.getView().byId("triptype").getSelectedIndex(),
                        "departdate": dDepartdate,
                        "returndate": dReturn,
                        "accomodation": this.getView().byId("accom").getSelectedIndex(),
                        "accpreference": accpreference,
                        "empnotes": this.getView().byId("additional").getValue(),
                        "Dextract" :  Model.getProperty("/aDataExtract")
                    }

                    var that = this;
                    $.ajax({
                        type: "PATCH",
                        contentType: "application/json",
                        url: url + "TravelRequest(ID=e8143969-45f2-4cb1-942c-617a4ced01c7)",
                        data: JSON.stringify(payload),
                        success: function (response) {
                            sap.m.MessageBox.success("Request has been Updated successfully");
                            $.ajax({
                                type: "GET",
                                contentType: "application/json",
                                url: url + "TravelRequest?$filter=reqstatus%20ne%20%27Completed%27&$orderby=REQID%20desc",
                                success: function (response) {
                                    for (let i = 0; i < response.value.length; i++) {
                                        if (response.value[i].triptype == 1) {
                                            response.value[i].triptype = "One way";
                                        }
                                        else {
                                            response.value[i].triptype = "Round way";
                                        }
                                        if (response.value[i].reqstatus == "PendingM") {
                                            response.value[i].reqstatus = "Pending with Manager";
                                        }
                                        else if (response.value[i].reqstatus == "ApprovedM") {
                                            response.value[i].reqstatus = "Approved by Manager";
                                        }
                                        else if (response.value[i].reqstatus == "ApprovedF") {
                                            response.value[i].reqstatus = "Approved by Finance";
                                        }
                                        else if (response.value[i].reqstatus == "RejectedM") {
                                            response.value[i].reqstatus = "Rejected by Manager";
                                        }
                                        else if (response.value[i].reqstatus == "RejectedF") {
                                            response.value[i].reqstatus = "Rejected by Finance";
                                        }
                                    }
                                    Model.setProperty("/aUpComingtrip", response.value);
                                    that.getView().byId("helloDialog").close();
                                },
                                error: function (error) {

                                }
                            })
                        },
                        error: function (error) {
                            sap.m.MessageBox.warning(error.responseJSON.valueOf("message").error.message);
                        }
                    })

                }
                else {
                    sap.m.MessageBox.error("Please fill the manadotory field.");
                }

            },

            onCancelPress1: function () {
                this.getView().byId("CreatedReq").close();
            },

            onSelectTravel: function (oEvent) {
                var Travel = this.getView().byId("rbg1").getSelectedButton().mProperties.text;
                if (Travel == "Car" || Travel == "Train") {
                    this.getView().byId("airid").setVisible(false);
                }
                else {
                    this.getView().byId("airid").setVisible(true);
                }

            },

            onSelectAccom: function (oEvent) {
                if (this.getView().byId("accom").getSelectedButton().mProperties.text != "Yes") {
                    this.getView().byId("anyprefrence").setVisible(false);
                }
                else {
                    this.getView().byId("anyprefrence").setVisible(true);
                }
            },

            onDeparture: function () {
                if (!this._oValueHelpDialog) {
                    Fragment.load({
                        name: "employee.fragments.DepartureCity",
                        controller: this
                    }).then(function (oDialog) {
                        this._oValueHelpDialog = oDialog;
                        this.getView().addDependent(this._oValueHelpDialog);
                        this._oValueHelpDialog.open();
                    }.bind(this));
                } else {
                    this._oValueHelpDialog.open();
                }
            },

            onValueHelpDialogClose: function () {
                this._oValueHelpDialog.close();
            },

            onDateReturn: function (oEvent) {
                const oReturnDate = oEvent.getParameter("value");
                const oDepartureDate = this.byId("DP1").getValue();
                if (oReturnDate && oDepartureDate) {
                    const oReturnDateObject = new Date(oReturnDate);
                    const oDepartureDateObject = new Date(oDepartureDate);

                    if (oReturnDateObject < oDepartureDateObject) {
                        // Show error message
                        sap.m.MessageToast.show("Return date must be after the departure date.");
                        // Optionally clear the return date field
                        this.byId("DP2").setValue("");
                    }
                }
                this.getView().byId("triptype").setSelectedIndex(1);
            },

            onRadioTrip: function (oEvent) {
                if (oEvent.getSource().mProperties.selectedIndex == 0) {
                    this.getView().byId("DP2").setValue("");
                }

            },

            onDestination: function () {
                if (!this._oValueHelpDialog1) {
                    Fragment.load({
                        name: "employee.fragments.DestinationCity",
                        controller: this
                    }).then(function (oDialog) {
                        this._oValueHelpDialog1 = oDialog;
                        this.getView().addDependent(this._oValueHelpDialog1);
                        this._oValueHelpDialog1.open();
                    }.bind(this));
                } else {
                    this._oValueHelpDialog1.open();
                }
            },

            onValueHelpDialogDest: function () {
                this._oValueHelpDialog1.close();
            },

            onItemPressDest: function (oEvent) {
                var oSelectedItem = oEvent.getSource();
                var oContext = oSelectedItem.getBindingContext("global");
                var selectedData = oContext.getObject();
                var oInput = this.byId("destination");
                oInput.setValue(selectedData.cityname);
                this._oValueHelpDialog1.close();
            },

            onItemPress: function (oEvent) {
                var oSelectedItem = oEvent.getSource();
                var oContext = oSelectedItem.getBindingContext("global");
                var selectedData = oContext.getObject();
                var oInput = this.byId("departure");
                oInput.setValue(selectedData.cityname);
                this._oValueHelpDialog.close();
            },

            onlPad: function (str, size) {
                var s = str.toString();
                while (s.length < size) {
                    s = "0" + s;
                }
                return s; // return new number
            },

            onSubmit: function () {
                var bFlag = true;
                var traveltype;
                var accpreference;
                var Model = this.getOwnerComponent().getModel("global");
                var url = this.getOwnerComponent().getModel().sServiceUrl;
                var empid = Model.getProperty("/aEmpInfo/empid");
                var fistname = Model.getProperty("/aEmpInfo/firstname");
                var lastname = Model.getProperty("/aEmpInfo/lastname");
                var dob = Model.getProperty("/aEmpInfo/dob");
                var dept = Model.getProperty("/aEmpInfo/dept");
                var emailid = Model.getProperty("/aEmpInfo/empemail");
                var mgrname = Model.getProperty("/aEmpInfo/mgrname");
                var mgremail = Model.getProperty("/aEmpInfo/mgremail");
                var mgrid = Model.getProperty("/aEmpInfo/mgrid");
                if(Model.getProperty("/aDataExtract") == undefined){
                    Model.setProperty("/aDataExtract", []);
                }
                else{
                    Model.setProperty("/aDataExtract", Model.getProperty("/aDataExtract"));
                }
                var dDepartdate = new Date(this.getView().byId("DP1").mProperties.dateValue).getFullYear() + '-' + (new Date(this.getView().byId("DP1").mProperties.dateValue).getMonth() + 1) + '-' + this.onlPad(new Date(this.getView().byId("DP1").mProperties.dateValue).getDate(), 2);

                var Travel = this.getView().byId("rbg1").getSelectedButton().mProperties.text;
                if (Travel == "Car" || Travel == "Train") {
                    traveltype = null;
                }
                else {
                    traveltype = this.getView().byId("airlines").getSelectedIndex();
                }
                if (this.getView().byId("accom").getSelectedButton().mProperties.text != "Yes") {
                    accpreference = "";
                }
                else {
                    accpreference = this.getView().byId("anyprefrence").getValue();
                }
                if (this.getView().byId("triptype").getSelectedIndex() == 0) {
                    var dReturn = null;
                }
                else {
                    var dReturn = new Date(this.getView().byId("DP2").mProperties.dateValue).getFullYear() + '-' + (new Date(this.getView().byId("DP2").mProperties.dateValue).getMonth() + 1) + '-' + this.onlPad(new Date(this.getView().byId("DP2").mProperties.dateValue).getDate(), 2);
                }
                if (this.getView().byId("purposetravel").getValue() == "") {
                    bFlag = false;
                    this.getView().byId("purposetravel").setValueState("Error");
                }
                if (this.getView().byId("departure").getValue() == "") {
                    bFlag = false;
                    this.getView().byId("departure").setValueState("Error");
                }
                if (this.getView().byId("destination").getValue() == "") {
                    bFlag = false;
                    this.getView().byId("destination").setValueState("Error");
                }
                if (this.getView().byId("DP1").getValue() == "") {
                    bFlag = false;
                    this.getView().byId("DP1").setValueState("Error");
                }
                if (this.getView().byId("triptype").getSelectedIndex == 1 && this.getView().byId("DP2").getValue == "") {
                    bFlag = false;
                    this.getView().byId("DP2").setValueState("Error");
                }
                // if (this.getView().byId("departure").getValue() === this.getView().byId("destination").getValue()) {
                //     sap.m.MessageBox.warning("Departure and destination cannot be same");
                // }
                if (bFlag == true) {
                    var payload = {
                        "empid": empid,
                        "firstname": fistname,
                        "lastname": lastname,
                        "dob": dob,
                        "dept": dept,
                        "emergencycontactno": "",
                        "mobno": "",
                        "emailid": emailid,
                        "address": "Pune",
                        "mgrid": mgrid,
                        "mgrname": mgrname,
                        "mgremail": mgremail,
                        "mgrcontact": "7876354625",
                        // "reqstatus": "",
                        "travelpreference": this.getView().byId("rbg1").getSelectedIndex(),
                        "traveltype": traveltype,
                        "purposeoftravel": this.getView().byId("purposetravel").getValue(),
                        "departcity": this.getView().byId("departure").getValue(),
                        "destcity": this.getView().byId("destination").getValue(),
                        "triptype": this.getView().byId("triptype").getSelectedIndex(),
                        "departdate": dDepartdate,
                        "returndate": dReturn,
                        "accomodation": this.getView().byId("accom").getSelectedIndex(),
                        "accpreference": accpreference,
                        "empnotes": this.getView().byId("additional").getValue(),
                        "Dextract" :  Model.getProperty("/aDataExtract")
                    }

                    var that = this;
                    $.ajax({
                        type: "POST",
                        contentType: "application/json",
                        url: url + "TravelRequest",
                        data: JSON.stringify(payload),
                        success: function (response) {
                            sap.m.MessageBox.success("Request has been submitted successfully");
                            $.ajax({
                                type: "GET",
                                contentType: "application/json",
                                url: url + "TravelRequest?$filter=reqstatus%20ne%20%27Completed%27&$orderby=REQID%20desc",
                                success: function (response) {
                                    for (let i = 0; i < response.value.length; i++) {
                                        if (response.value[i].triptype == 1) {
                                            response.value[i].triptype = "One way";
                                        }
                                        else {
                                            response.value[i].triptype = "Round way";
                                        }
                                        if (response.value[i].reqstatus == "PendingM") {
                                            response.value[i].reqstatus = "Pending with Manager";
                                        }
                                        else if (response.value[i].reqstatus == "ApprovedM") {
                                            response.value[i].reqstatus = "Approved by Manager";
                                        }
                                        else if (response.value[i].reqstatus == "ApprovedF") {
                                            response.value[i].reqstatus = "Approved by Finance";
                                        }
                                        else if (response.value[i].reqstatus == "RejectedM") {
                                            response.value[i].reqstatus = "Rejected by Manager";
                                        }
                                        else if (response.value[i].reqstatus == "RejectedF") {
                                            response.value[i].reqstatus = "Rejected by Finance";
                                        }
                                    }
                                    Model.setProperty("/aUpComingtrip", response.value);
                                    that.getView().byId("helloDialog").close();
                                },
                                error: function (error) {

                                }
                            })
                        },
                        error: function (error) {
                            sap.m.MessageBox.warning(error.responseJSON.valueOf("message").error.message);
                        }
                    })

                }
                else {
                    sap.m.MessageBox.error("Please fill the manadotory field.");
                }







            },

            onCancelPress: function (oEvent) {
                this.getView().byId("helloDialog").close();
            }
        });
    });
